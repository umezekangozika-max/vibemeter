import { isRelevantToCategory, resolveCategoryDefinition } from '../src/config/categoryConfig.ts';

const testCases = [
  // --- TRAVEL CATEGORY TESTS ---
  {
    category: 'travel',
    title: 'Cape Town South Africa: 4K Travel Documentary & Hidden Gems',
    expected: true,
    description: 'Travel documentary should be ACCEPTED for Travel'
  },
  {
    category: 'travel',
    title: '10 Must-See Places in Santorini Greece | Complete Destination Guide',
    expected: true,
    description: 'Destination guide should be ACCEPTED for Travel'
  },
  {
    category: 'travel',
    title: 'Morgan Wallen - Last Night (Official Music Video) Country Performance',
    expected: false,
    description: 'Country music performance should be REJECTED from Travel'
  },
  {
    category: 'travel',
    title: 'Smile 2 | Official Teaser Trailer | Horror Movie',
    expected: false,
    description: 'Horror movie trailer should be REJECTED from Travel'
  },
  {
    category: 'travel',
    title: 'The Great African Safari Tour & Serengeti Wildlife Documentary',
    expected: true,
    description: 'African wildlife safari travel should be ACCEPTED for Travel'
  },

  // --- FASHION CATEGORY TESTS ---
  {
    category: 'fashion',
    title: 'Lagos Fashion Week: Runway Highlights & Modern Adire Style',
    expected: true,
    description: 'Runway highlights should be ACCEPTED for Fashion'
  },
  {
    category: 'fashion',
    title: 'Streetwear Lookbook & Sneaker Releases 2025',
    expected: true,
    description: 'Streetwear lookbook should be ACCEPTED for Fashion'
  },
  {
    category: 'fashion',
    title: 'How to Solve Linear Equations in Algebra (Math Lesson)',
    expected: false,
    description: 'Math lesson should be REJECTED from Fashion'
  },

  // --- RELATIONSHIPS CATEGORY TESTS ---
  {
    category: 'relationships',
    title: 'Healthy Communication Skills That Transform Your Relationships',
    expected: true,
    description: 'Communication skills should be ACCEPTED for Relationships'
  },
  {
    category: 'relationships',
    title: 'Dating Advice: How to Build Emotional Intelligence with Your Partner',
    expected: true,
    description: 'Dating advice should be ACCEPTED for Relationships'
  },
  {
    category: 'relationships',
    title: 'Arsenal vs Chelsea Highlights | Premier League Goals',
    expected: false,
    description: 'Football match highlights should be REJECTED from Relationships'
  },

  // --- SPORTS CATEGORY TESTS ---
  {
    category: 'sports',
    title: 'Top 10 Most Iconic Goals in AFCON History | Football Highlights',
    expected: true,
    description: 'AFCON football highlights should be ACCEPTED for Sports'
  },
  {
    category: 'sports',
    title: 'How to Cook Smoky Nigerian Jollof Rice (Recipe Tutorial)',
    expected: false,
    description: 'Cooking tutorial should be REJECTED from Sports'
  },

  // --- BUSINESS CATEGORY TESTS ---
  {
    category: 'business',
    title: 'How Startup Founders Scale Fintech Ecosystems Across Africa',
    expected: true,
    description: 'Startup entrepreneurship should be ACCEPTED for Business'
  },
  {
    category: 'business',
    title: 'Ayra Starr - Rush (Official Music Video)',
    expected: false,
    description: 'Music video should be REJECTED from Business'
  },

  // --- EDUCATION CATEGORY TESTS ---
  {
    category: 'education',
    title: 'Python Programming Full Course for Beginners: Learn Coding',
    expected: true,
    description: 'Programming tutorial should be ACCEPTED for Education'
  },
  {
    category: 'education',
    title: 'Scream 7 | Official Horror Movie Trailer',
    expected: false,
    description: 'Horror movie trailer should be REJECTED from Education'
  },

  // --- MUSIC CATEGORY TESTS ---
  {
    category: 'music',
    title: 'Burna Boy - City Boys [Official Music Video]',
    expected: true,
    description: 'Official music video should be ACCEPTED for Music'
  },
  {
    category: 'music',
    title: 'Samsung Galaxy S25 Ultra Hardware Review & Specs',
    expected: false,
    description: 'Smartphone review should be REJECTED from Music'
  },

  // --- HEALTH & WELLNESS CATEGORY TESTS ---
  {
    category: 'health',
    title: '20 Min Full Body Workout - Daily Fitness & Mobility Routine',
    expected: true,
    description: 'Workout routine should be ACCEPTED for Health'
  },
  {
    category: 'health',
    title: 'GTA 6 Gameplay Walkthrough Part 1',
    expected: false,
    description: 'Video game walkthrough should be REJECTED from Health'
  },

  // --- TECH & GADGETS CATEGORY TESTS ---
  {
    category: 'technology',
    title: 'MKBHD Smartphone Awards: Best Hardware & AI Devices 2025',
    expected: true,
    description: 'Smartphone hardware review should be ACCEPTED for Tech'
  },
  {
    category: 'technology',
    title: 'Luke Combs - Fast Car (Live Country Music Performance)',
    expected: false,
    description: 'Country music performance should be REJECTED from Tech'
  }
];

let passed = 0;
let failed = 0;

console.log('--- RUNNING VIBEMETER CATEGORY RELEVANCE REGRESSION TESTS ---\n');

for (const tc of testCases) {
  const result = isRelevantToCategory({ title: tc.title }, tc.category);
  const isMatch = result.isRelevant === tc.expected;
  if (isMatch) {
    passed++;
    console.log(`✓ PASS: [${tc.category.toUpperCase()}] ${tc.description}`);
  } else {
    failed++;
    console.error(`✗ FAIL: [${tc.category.toUpperCase()}] ${tc.description}`);
    console.error(`  Title: "${tc.title}"`);
    console.error(`  Expected: ${tc.expected}, Got: ${result.isRelevant} (${result.reason})`);
  }
}

console.log(`\nRegression Test Summary: ${passed} passed, ${failed} failed out of ${testCases.length} total.`);

if (failed > 0) {
  process.exit(1);
} else {
  console.log('ALL CATEGORY RELEVANCE TESTS PASSED SUCCESSFULLY!\n');
}
