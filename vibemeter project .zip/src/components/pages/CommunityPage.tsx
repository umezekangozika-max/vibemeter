import React, { useState } from 'react';
import { 
  Users, 
  MessageSquare, 
  Heart, 
  Send, 
  Sparkles, 
  Mail, 
  CheckCircle2, 
  Share2 
} from 'lucide-react';

export const CommunityPage: React.FC = () => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [communityThreads, setCommunityThreads] = useState([
    {
      id: 't-1',
      author: 'Amara_Design',
      handle: '@amara_d',
      avatar: 'https://i.ytimg.com/vi/YV4rQ1K_VbY/hqdefault.jpg',
      content: 'Which African city has the best fashion week scene in 2025? Lagos vs Johannesburg vs Casablanca? Let’s debate! 👗✨',
      likes: 342,
      replies: 58,
      time: '3h ago'
    },
    {
      id: 't-2',
      author: 'DavidK_Beats',
      handle: '@davidk',
      avatar: 'https://i.ytimg.com/vi/4TWRwO8yOQU/hqdefault.jpg',
      content: 'The percussion on Asake and Burna Boy’s new records is top tier spiritual production. Can we talk about the horn arrangement?! 🎷🔥',
      likes: 819,
      replies: 124,
      time: '6h ago'
    },
    {
      id: 't-3',
      author: 'NiaTravels',
      handle: '@nia_travels',
      avatar: 'https://i.ytimg.com/vi/tO01J-13nCE/hqdefault.jpg',
      content: 'Just returned from a 7-day trip to Zanzibar and Santorini. Tip: Always book the sunset caldera boat tour 3 weeks in advance! 🌊☀️',
      likes: 620,
      replies: 42,
      time: '1d ago'
    }
  ]);

  const [newThreadText, setNewThreadText] = useState('');

  const handlePostThread = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newThreadText.trim()) return;

    setCommunityThreads([
      {
        id: `t-${Date.now()}`,
        author: 'You (VIP Member)',
        handle: '@you',
        avatar: 'https://i.ytimg.com/vi/9g_7e2Ym_E8/hqdefault.jpg',
        content: newThreadText.trim(),
        likes: 1,
        replies: 0,
        time: 'Just now'
      },
      ...communityThreads
    ]);
    setNewThreadText('');
  };

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes('@')) return;

    setSubmitting(true);
    try {
      await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: newsletterEmail })
      });
      setSubscribed(true);
    } catch {
      setSubscribed(true);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300 max-w-4xl mx-auto">
      
      {/* Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#1b1735] via-[#141628] to-[#121323] border border-[#8b25ff]/30 text-center space-y-3">
        <span className="px-3 py-1 rounded-full bg-[#8b25ff]/20 text-[#00f2fe] text-xs font-bold border border-[#8b25ff]/40">
          The VibeMeter Tribe
        </span>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-display">
          Community & Global Conversations
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
          Connect with 12,000+ creators, travelers, audiophiles, and cultural connoisseurs across Africa and the world.
        </p>
      </div>

      {/* New Post Input */}
      <div className="p-4 sm:p-6 rounded-3xl bg-[#131422] border border-white/10 space-y-3">
        <h3 className="text-sm font-bold text-white">Start a Conversation</h3>
        <form onSubmit={handlePostThread} className="space-y-3">
          <textarea
            rows={3}
            value={newThreadText}
            onChange={(e) => setNewThreadText(e.target.value)}
            placeholder="Share a thought, recommendation, or question with the community..."
            className="w-full p-3.5 rounded-2xl bg-[#181a2e] border border-white/10 text-white text-xs sm:text-sm focus:border-[#ff007a] focus:outline-none"
          />
          <div className="flex justify-end">
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#ff007a] to-[#8b25ff] hover:opacity-90 text-white text-xs font-bold flex items-center gap-1.5 transition-transform active:scale-95 shadow-md"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Post to Feed</span>
            </button>
          </div>
        </form>
      </div>

      {/* Community Feed */}
      <div className="space-y-4">
        {communityThreads.map((thread) => (
          <div
            key={thread.id}
            className="p-5 rounded-2xl bg-[#131422] border border-white/5 space-y-3 hover:border-white/15 transition-colors"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={thread.avatar}
                  alt={thread.author}
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-full object-cover ring-2 ring-[#ff007a]/40"
                />
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-white">{thread.author}</h4>
                  <span className="text-[11px] text-slate-400">{thread.handle}</span>
                </div>
              </div>
              <span className="text-[11px] text-slate-400">{thread.time}</span>
            </div>

            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
              {thread.content}
            </p>

            <div className="flex items-center gap-6 pt-2 text-xs text-slate-400 border-t border-white/5">
              <button className="flex items-center gap-1.5 hover:text-rose-400 transition-colors">
                <Heart className="w-3.5 h-3.5" />
                <span>{thread.likes}</span>
              </button>
              <button className="flex items-center gap-1.5 hover:text-[#00f2fe] transition-colors">
                <MessageSquare className="w-3.5 h-3.5" />
                <span>{thread.replies} Replies</span>
              </button>
              <button className="flex items-center gap-1.5 hover:text-white transition-colors">
                <Share2 className="w-3.5 h-3.5" />
                <span>Share</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Newsletter Signup Section */}
      <div className="p-8 rounded-3xl bg-gradient-to-br from-[#1a1c32] via-[#141628] to-[#0f1120] border border-white/10 text-center space-y-4">
        <Mail className="w-8 h-8 text-[#ff007a] mx-auto" />
        <h3 className="text-xl font-bold text-white font-display">
          Join the VibeMeter VIP Newsletter
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto">
          Get weekly curated drops: secret travel deals, Afrobeats premiere notifications, and creator toolkits straight to your inbox.
        </p>

        {subscribed ? (
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-400 text-xs font-bold border border-emerald-500/30">
            <CheckCircle2 className="w-4 h-4" />
            <span>You're in! Welcome to the VibeMeter inner circle.</span>
          </div>
        ) : (
          <form onSubmit={handleNewsletterSubmit} className="max-w-md mx-auto flex gap-2">
            <input
              type="email"
              required
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              placeholder="Enter your email address..."
              className="flex-1 px-4 py-2.5 rounded-xl bg-[#191b2e] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
            />
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#ff007a] to-[#8b25ff] hover:opacity-90 text-white text-xs font-bold transition-all disabled:opacity-50"
            >
              {submitting ? 'Subscribing...' : 'Subscribe'}
            </button>
          </form>
        )}
      </div>

    </div>
  );
};
