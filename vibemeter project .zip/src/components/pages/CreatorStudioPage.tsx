import React, { useState } from 'react';
import { 
  PenSquare, 
  Upload, 
  BarChart3, 
  DollarSign, 
  Users, 
  CheckCircle2, 
  Clock, 
  Sparkles,
  ArrowRight
} from 'lucide-react';

export const CreatorStudioPage: React.FC = () => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Music');
  const [content, setContent] = useState('');
  const [tags, setTags] = useState('Afrobeats, Culture, Sound');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setSubmitting(true);
    try {
      await fetch('/api/creator/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          category,
          creator: 'Creator Partner',
          content,
          tags: tags.split(',').map(t => t.trim())
        })
      });
      setSubmitted(true);
      setTitle('');
      setContent('');
    } catch {
      setSubmitted(true);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300 max-w-5xl mx-auto">
      
      {/* Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#17162e] via-[#1a1835] to-[#121323] border border-[#ff007a]/30 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div>
          <span className="px-3 py-1 rounded-full bg-[#ff007a]/20 text-[#ff007a] text-xs font-bold border border-[#ff007a]/40">
            Creator Dashboard
          </span>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-display mt-2">
            Creator Studio & Monetization
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
            Publish original entertainment, lifestyle stories, music videos, and track revenue sharing.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center">
            <span className="text-xl font-bold text-emerald-400 font-mono">$1,480.00</span>
            <span className="block text-[10px] text-slate-400">Earned This Month</span>
          </div>
        </div>
      </div>

      {/* Creator Analytics Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#131422] border border-white/5">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Views</span>
            <BarChart3 className="w-4 h-4 text-[#ff007a]" />
          </div>
          <div className="text-2xl font-bold text-white font-mono mt-2">2.4M</div>
          <span className="text-[10px] text-emerald-400 font-semibold">+18.4% vs last mo</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#131422] border border-white/5">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Subscribers</span>
            <Users className="w-4 h-4 text-[#8b25ff]" />
          </div>
          <div className="text-2xl font-bold text-white font-mono mt-2">48.2K</div>
          <span className="text-[10px] text-emerald-400 font-semibold">+3.1K new</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#131422] border border-white/5">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Engagement</span>
            <Sparkles className="w-4 h-4 text-[#00f2fe]" />
          </div>
          <div className="text-2xl font-bold text-white font-mono mt-2">8.9%</div>
          <span className="text-[10px] text-emerald-400 font-semibold">Above average</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#131422] border border-white/5">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Ad Revenue</span>
            <DollarSign className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono mt-2">$850.50</div>
          <span className="text-[10px] text-slate-400">Net payout ready</span>
        </div>
      </div>

      {/* Submission Form */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#131422] border border-white/10 space-y-6">
        <div className="flex items-center gap-2">
          <PenSquare className="w-5 h-5 text-[#ff007a]" />
          <h2 className="text-lg font-bold text-white font-display">Submit Original Content</h2>
        </div>

        {submitted ? (
          <div className="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-3">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <h3 className="text-base font-bold text-white">Submission Sent for Editorial Review!</h3>
            <p className="text-xs text-slate-300 max-w-md mx-auto">
              Our editorial moderation team reviews submissions within 24 hours. Once approved, your vibe will be indexed on the discovery feeds.
            </p>
            <button
              onClick={() => setSubmitted(false)}
              className="mt-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold"
            >
              Submit Another Post
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Title</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Asake's Groundbreaking Stadium Tour: Inside the Set Design"
                className="w-full px-4 py-2.5 rounded-xl bg-[#181a2e] border border-white/10 text-white text-sm focus:border-[#ff007a] focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-[#181a2e] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
                >
                  <option value="Music">Music & Afrobeats</option>
                  <option value="Movies">Movies & Cinema</option>
                  <option value="Lifestyle">Lifestyle & Wellness</option>
                  <option value="Fashion">Fashion & Beauty</option>
                  <option value="Travel">Travel & Destinations</option>
                  <option value="Food">Food & Recipes</option>
                  <option value="Technology">Tech & Gadgets</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Tags (comma separated)</label>
                <input
                  type="text"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  placeholder="Afrobeats, Fashion, Lagos"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#181a2e] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Article or Video Summary</label>
              <textarea
                rows={4}
                required
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Write your article breakdown, interview notes, or video description..."
                className="w-full p-4 rounded-xl bg-[#181a2e] border border-white/10 text-white text-xs sm:text-sm focus:border-[#ff007a] focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-3 rounded-full bg-gradient-to-r from-[#ff007a] to-[#8b25ff] hover:opacity-90 text-white text-xs sm:text-sm font-bold shadow-lg shadow-[#ff007a]/30 transition-all active:scale-95 flex items-center gap-2"
            >
              <span>{submitting ? 'Submitting...' : 'Submit to VibeMeter'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}
      </div>

    </div>
  );
};
