import React, { useState, useEffect } from 'react';
import { 
  Flame, 
  ArrowUpRight, 
  Eye, 
  Heart, 
  Play,
  Radio, 
  Loader2,
  ChevronDown,
  CheckCircle2
} from 'lucide-react';
import { TRENDING_LEADERBOARD, ALL_CONTENT } from '../../data/mockData';
import { TrendingItem, ContentItem } from '../../types';

interface TrendingPageProps {
  onSelectItem: (item: ContentItem) => void;
}

export const TrendingPage: React.FC<TrendingPageProps> = ({ onSelectItem }) => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [trendingItems, setTrendingItems] = useState<TrendingItem[]>(TRENDING_LEADERBOARD);
  const [visibleCount, setVisibleCount] = useState<number>(8);
  const [loading, setLoading] = useState(false);

  const categories = ['All', 'Music', 'Travel', 'Lifestyle', 'Tech', 'Fashion', 'Food', 'Sports', 'Movies'];

  useEffect(() => {
    let isCancelled = false;

    const fetchTrendingVideos = async () => {
      setLoading(true);
      try {
        const endpoint = activeCategory === 'All' 
          ? '/api/youtube/trending' 
          : `/api/youtube/category?category=${activeCategory.toLowerCase()}`;
        const res = await fetch(endpoint);
        if (res.ok && !isCancelled) {
          const data = await res.json();
          if (data.items && Array.isArray(data.items) && data.items.length > 0) {
            const seenIds = new Set<string>();
            const mapped: TrendingItem[] = [];

            for (const yt of data.items) {
              if (!yt) continue;
              const id = yt.id || yt.videoId;
              if (!id || typeof id !== 'string' || seenIds.has(id)) continue;
              const title = (yt.title || '').trim();
              if (!title || title.toLowerCase().includes('[deleted video]') || title.toLowerCase().includes('[private video]')) continue;

              seenIds.add(id);
              mapped.push({
                rank: mapped.length + 1,
                title: title,
                category: yt.category || (activeCategory === 'All' ? 'Entertainment' : activeCategory),
                views: yt.views || '1.2M',
                likes: yt.likes || '85K',
                thumbnailUrl: yt.thumbnailUrl || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
                creator: yt.creator || 'Verified Channel',
                duration: yt.duration || 'Video',
                change: mapped.length % 2 === 0 ? 'up' : 'steady'
              });
            }

            if (mapped.length > 0) {
              setTrendingItems(mapped);
              setVisibleCount(8);
              return;
            }
          }
        }
      } catch {
        // Keeps fallback
      } finally {
        if (!isCancelled) {
          setLoading(false);
        }
      }

      if (!isCancelled) {
        setVisibleCount(8);
      }
    };

    fetchTrendingVideos();

    return () => {
      isCancelled = true;
    };
  }, [activeCategory]);

  // Max limit of 20 trending videos for this view
  const maxAvailable = Math.min(20, trendingItems.length);
  const displayedItems = trendingItems.slice(0, visibleCount);
  const hasMore = visibleCount < maxAvailable;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-orange-500/20 via-red-500/10 to-[#121323] border border-orange-500/30 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Flame className="w-5 h-5 text-orange-400 fill-orange-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-orange-400">
              Live YouTube Leaderboards
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-red-600/20 border border-red-500/30 text-red-400 text-xs font-bold">
              <Radio className="w-3 h-3 animate-pulse text-red-500" />
              <span>Real Streams</span>
            </span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-display">
            Trending Leaderboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
            Real-time cultural pulse, streaming charts, viral discussions, and top creator video highlights.
          </p>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setActiveCategory(c)}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${
              activeCategory === c
                ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-md'
                : 'bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Leaderboard Table / Cards */}
      {loading ? (
        <div className="py-12 flex flex-col items-center justify-center space-y-3">
          <Loader2 className="w-8 h-8 text-orange-400 animate-spin" />
          <p className="text-xs text-slate-400">Loading YouTube trending leaderboards...</p>
        </div>
      ) : (
        <div className="space-y-3">
          {displayedItems.map((item) => {
            const videoId = item.thumbnailUrl.includes('vi/') 
              ? item.thumbnailUrl.split('vi/')[1].split('/')[0] 
              : '4TWRwO8yOQU';

            const matchedContent: ContentItem = ALL_CONTENT.find(c => c.id === videoId || c.title.toLowerCase().includes(item.title.toLowerCase().slice(0, 15))) || {
              id: videoId,
              title: item.title,
              slug: item.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
              summary: `Trending #${item.rank} on YouTube charts with ${item.views} views and ${item.likes} likes.`,
              category: item.category,
              contentType: 'video',
              duration: item.duration,
              views: item.views,
              likes: item.likes,
              comments: '1.2K',
              creator: {
                name: item.creator,
                handle: `@${item.creator.toLowerCase().replace(/\s+/g, '')}`,
                avatar: item.thumbnailUrl,
                verified: true
              },
              publishedAt: 'Trending Stream',
              thumbnailUrl: item.thumbnailUrl,
              mediaEmbedUrl: `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&enablejsapi=1`,
              tags: ['Trending', item.category, 'YouTube']
            };

            return (
              <div
                key={item.rank}
                onClick={() => onSelectItem(matchedContent)}
                className="p-4 rounded-2xl bg-[#131422] border border-white/5 hover:border-orange-500/40 flex items-center gap-4 transition-all duration-200 cursor-pointer group hover:bg-[#181a2e]"
              >
                {/* Rank */}
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-orange-500 to-red-500 text-white font-extrabold text-base flex items-center justify-center shrink-0 shadow-md">
                  #{item.rank}
                </div>

                {/* Thumbnail with Play Hover */}
                <div className="w-24 aspect-[16/10] rounded-xl overflow-hidden shrink-0 bg-black relative shadow">
                  <img
                    src={item.thumbnailUrl}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-5 h-5 fill-white text-white" />
                  </div>
                </div>

                {/* Title & Category */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white/10 text-slate-300">
                      {item.category}
                    </span>
                    <span className="text-xs text-slate-400">· {item.creator}</span>
                  </div>
                  <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-orange-400 transition-colors truncate mt-1">
                    {item.title}
                  </h3>
                </div>

                {/* Views & Likes */}
                <div className="flex items-center gap-4 text-xs text-slate-400 shrink-0">
                  <div className="flex items-center gap-1.5">
                    <Eye className="w-4 h-4 text-slate-500" />
                    <span className="font-mono text-slate-200 font-semibold">{item.views}</span>
                  </div>
                  <div className="flex items-center gap-1.5 hidden sm:flex">
                    <Heart className="w-4 h-4 text-rose-500 fill-rose-500/20" />
                    <span className="font-mono text-slate-200">{item.likes}</span>
                  </div>
                </div>

                <div className="p-2 rounded-xl bg-white/5 text-slate-400 group-hover:text-white transition-colors shrink-0">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
            );
          })}

          {/* Load More Control Bar (up to 20 videos) */}
          {trendingItems.length > 0 && (
            <div className="pt-6 pb-2 flex flex-col items-center justify-center gap-3">
              {hasMore ? (
                <button
                  onClick={() => setVisibleCount(prev => Math.min(maxAvailable, prev + 4))}
                  className="group px-7 py-3 rounded-2xl bg-gradient-to-r from-orange-500/20 via-red-500/20 to-amber-500/20 hover:from-orange-500 hover:to-red-500 text-white text-xs font-bold border border-orange-500/30 hover:border-transparent flex items-center gap-2.5 transition-all duration-300 shadow-lg hover:shadow-orange-500/25 active:scale-95 cursor-pointer"
                >
                  <span>Load More Trending Videos</span>
                  <ChevronDown className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" />
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/20 text-white font-mono font-semibold">
                    +{Math.min(4, maxAvailable - visibleCount)}
                  </span>
                </button>
              ) : maxAvailable >= 8 ? (
                <div className="flex items-center gap-2 text-xs text-slate-400 bg-white/[0.04] px-4 py-2 rounded-full border border-white/5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>All {displayedItems.length} trending items loaded</span>
                </div>
              ) : null}

              <p className="text-[11px] text-slate-500">
                Showing {displayedItems.length} of {maxAvailable} trending videos {maxAvailable >= 20 ? '(maximum reached)' : ''}
              </p>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
