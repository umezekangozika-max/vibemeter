import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Radio, 
  Loader2, 
  Flame, 
  Search, 
  Sparkles, 
  Tv, 
  RefreshCw,
  ExternalLink,
  Tag
} from 'lucide-react';
import { ContentItem } from '../../types';
import { VideoCard } from '../VideoCard';

interface VideosPageProps {
  onSelectItem: (item: ContentItem) => void;
}

export const VideosPage: React.FC<VideosPageProps> = ({ onSelectItem }) => {
  const [items, setItems] = useState<ContentItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'all' | 'streetwear' | 'startups' | 'music'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const fetchVideos = async (isManual = false) => {
    if (isManual) setRefreshing(true);
    else setLoading(true);

    try {
      // First attempt the dedicated videos RSS + YouTube hybrid endpoint
      const res = await fetch(`/api/rss/feed?category=videos&refresh=${isManual}&t=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        if (data.items && data.items.length > 0) {
          const mapped: ContentItem[] = data.items.map((yt: any, index: number) => ({
            id: yt.id,
            title: yt.title,
            slug: yt.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
            summary: yt.summary || 'Trending cultural video drop supplemented via Hypebeast.',
            category: 'Videos',
            contentType: 'video' as const,
            duration: yt.duration || '12:00',
            views: yt.views || '650K',
            likes: yt.likes || '45K',
            comments: yt.comments || '1.2K',
            creator: {
              name: yt.creator || 'VibeMeter Videos',
              handle: `@${(yt.creator || 'creator').toLowerCase().replace(/\s+/g, '')}`,
              avatar: yt.thumbnailUrl || `https://i.ytimg.com/vi/${yt.id}/hqdefault.jpg`,
              verified: true,
              role: 'Verified Channel'
            },
            publishedAt: yt.publishedAt || 'Recently Published',
            thumbnailUrl: yt.thumbnailUrl || `https://i.ytimg.com/vi/${yt.id}/hqdefault.jpg`,
            mediaEmbedUrl: `https://www.youtube-nocookie.com/embed/${yt.id}?autoplay=1&enablejsapi=1`,
            tags: ['YouTube', 'Videos', yt.title.toLowerCase().includes('streetwear') ? 'Streetwear' : 'Startups'],
            featured: index < 2
          }));
          setItems(mapped);
          setLoading(false);
          setRefreshing(false);
          return;
        }
      }

      // Secondary fallback to category videos endpoint
      const catRes = await fetch(`/api/youtube/category?category=videos`);
      if (catRes.ok) {
        const catData = await catRes.json();
        if (catData.items && catData.items.length > 0) {
          const mapped = catData.items.map((yt: any) => ({
            id: yt.id,
            title: yt.title,
            slug: yt.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
            summary: yt.summary,
            category: 'Videos',
            contentType: 'video' as const,
            duration: yt.duration,
            views: yt.views,
            likes: yt.likes,
            comments: yt.comments,
            creator: {
              name: yt.creator,
              handle: `@${yt.creator.toLowerCase().replace(/\s+/g, '')}`,
              avatar: yt.thumbnailUrl,
              verified: true
            },
            publishedAt: yt.publishedAt,
            thumbnailUrl: yt.thumbnailUrl,
            mediaEmbedUrl: yt.embedUrl,
            tags: ['YouTube', 'Videos']
          }));
          setItems(mapped);
        }
      }
    } catch {
      // Kept current
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchVideos();
  }, []);

  const filteredItems = items.filter(item => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match = 
        item.title.toLowerCase().includes(q) ||
        item.summary.toLowerCase().includes(q) ||
        item.creator.name.toLowerCase().includes(q);
      if (!match) return false;
    }

    if (activeFilter === 'streetwear') {
      return item.title.toLowerCase().includes('streetwear') || item.title.toLowerCase().includes('corteiz') || item.title.toLowerCase().includes('sneaker') || item.title.toLowerCase().includes('fashion');
    }
    if (activeFilter === 'startups') {
      return item.title.toLowerCase().includes('startup') || item.title.toLowerCase().includes('business') || item.title.toLowerCase().includes('fintech') || item.title.toLowerCase().includes('tech');
    }
    if (activeFilter === 'music') {
      return item.title.toLowerCase().includes('music') || item.title.toLowerCase().includes('burna') || item.title.toLowerCase().includes('asake') || item.title.toLowerCase().includes('sound');
    }
    return true;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* 1. Videos Masthead with YouTube Live Status */}
      <header className="p-6 sm:p-10 rounded-3xl bg-gradient-to-r from-[#1a1226] via-[#20112e] to-[#121323] border border-[#ff007a]/30 shadow-2xl relative overflow-hidden">
        <div className="max-w-3xl space-y-3 relative z-10">
          
          <div className="flex flex-wrap items-center gap-2 pb-2">
            <span className="px-3 py-1 rounded-full bg-red-600/20 border border-red-500/40 text-red-400 text-xs font-black uppercase flex items-center gap-1.5">
              <Radio className="w-3 h-3 text-red-500 animate-pulse" />
              <span>Active YouTube API Engine</span>
            </span>
            <span className="px-3 py-1 rounded-full bg-blue-600/20 border border-blue-500/40 text-blue-300 text-xs font-bold font-mono">
              Queries: "Streetwear fashion drops" & "startup business trends"
            </span>
            <span className="px-3 py-1 rounded-full bg-purple-600/20 border border-purple-500/40 text-purple-300 text-xs font-bold">
              Summaries: Hypebeast Editorial
            </span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white font-display tracking-tight uppercase">
            Cultural <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#ff007a] to-[#8b25ff]">Video Hub</span>
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed max-w-2xl">
            Live syndicated YouTube streams covering limited streetwear drops, venture startup trends, and global creator culture — with text article summaries supplemented safely via Hypebeast.
          </p>
        </div>

        {/* Toolbar */}
        <div className="mt-8 pt-6 border-t border-white/10 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 relative z-10">
          
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'all', label: 'All Streams' },
              { id: 'streetwear', label: '👟 Streetwear Drops' },
              { id: 'startups', label: '📈 Startup Trends' },
              { id: 'music', label: '🎵 Visualizers & Sound' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveFilter(tab.id as any)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                  activeFilter === tab.id
                    ? 'bg-gradient-to-r from-[#ff007a] to-[#8b25ff] text-white shadow-lg shadow-[#ff007a]/30'
                    : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Controls: Search + Sync */}
          <div className="flex items-center gap-3">
            <div className="relative w-full sm:w-60">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search video titles..."
                className="w-full pl-9 pr-3 py-1.5 bg-white/5 border border-white/10 rounded-full text-xs text-white placeholder-slate-400 focus:outline-none focus:border-[#ff007a]"
              />
            </div>

            <button
              onClick={() => fetchVideos(true)}
              disabled={refreshing || loading}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white border border-white/10 transition-colors disabled:opacity-50 shrink-0"
              title="Refresh live video streams"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#00f2fe] ${refreshing ? 'animate-spin' : ''}`} />
            </button>
          </div>

        </div>
      </header>

      {/* 2. Video Grid with Playable VideoCards */}
      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center space-y-4">
          <Loader2 className="w-10 h-10 text-[#ff007a] animate-spin" />
          <p className="text-sm font-mono text-slate-400">
            Querying YouTube API for streetwear drops & startup trends...
          </p>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-[#121323] border border-white/10 space-y-3">
          <p className="text-base font-bold text-white font-display">No videos found</p>
          <p className="text-xs text-slate-400">Try switching your category filter or clearing your search.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <VideoCard
              key={item.id}
              item={item}
              onSelect={onSelectItem}
            />
          ))}
        </div>
      )}

    </div>
  );
};
