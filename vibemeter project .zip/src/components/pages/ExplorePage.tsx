import React, { useState, useEffect } from 'react';
import { 
  SlidersHorizontal, 
  Radio,
  Loader2
} from 'lucide-react';
import { ALL_CONTENT } from '../../data/mockData';
import { ContentItem } from '../../types';
import { VideoCard } from '../VideoCard';

interface ExplorePageProps {
  onSelectItem: (item: ContentItem) => void;
  onOpenAiModal: () => void;
}

export const ExplorePage: React.FC<ExplorePageProps> = ({
  onSelectItem,
  onOpenAiModal
}) => {
  const [selectedTag, setSelectedTag] = useState('All');
  const [sortBy, setSortBy] = useState<'trending' | 'recent' | 'popular'>('trending');
  const [items, setItems] = useState<ContentItem[]>(ALL_CONTENT);
  const [loading, setLoading] = useState(false);

  const TAGS = ['All', 'Music', 'Fashion', 'Tech', 'Travel', 'Lifestyle', 'Food', 'Movies', 'Sports', 'Health', 'Relationships', 'Business', 'Education'];

  useEffect(() => {
    const fetchCategoryFeed = async () => {
      setLoading(true);
      try {
        const catParam = selectedTag === 'All' ? 'trending' : selectedTag.toLowerCase();
        const endpoint = selectedTag === 'All' ? '/api/youtube/trending' : `/api/youtube/category?category=${encodeURIComponent(catParam)}`;
        const res = await fetch(endpoint);
        if (res.ok) {
          const data = await res.json();
          if (data.items && data.items.length > 0) {
            const mapped: ContentItem[] = data.items.map((yt: any) => ({
              id: yt.id,
              title: yt.title,
              slug: yt.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
              summary: yt.summary || `Authentic ${selectedTag} stream from ${yt.creator || 'VibeMeter'}.`,
              category: yt.category || (selectedTag === 'All' ? 'Entertainment' : selectedTag),
              contentType: 'video' as const,
              duration: yt.duration || 'Video',
              views: yt.views || '',
              likes: yt.likes || '',
              comments: yt.comments || '',
              isLive: Boolean(yt.isLive),
              creator: {
                name: yt.creator || 'Verified Channel',
                handle: `@${(yt.creator || 'creator').toLowerCase().replace(/[^a-z0-9]/g, '')}`,
                avatar: yt.thumbnailUrl || `https://i.ytimg.com/vi/${yt.id}/hqdefault.jpg`,
                verified: true,
                role: 'Channel Host'
              },
              publishedAt: yt.publishedAt || 'Recently Published',
              thumbnailUrl: yt.thumbnailUrl || `https://i.ytimg.com/vi/${yt.id}/hqdefault.jpg`,
              mediaEmbedUrl: yt.embedUrl || `https://www.youtube-nocookie.com/embed/${yt.id}?autoplay=1&enablejsapi=1`,
              tags: ['YouTube', selectedTag, 'Explore'],
              featured: true
            }));
            setItems(mapped);
          }
        }
      } catch {
        // Keeps fallback
      } finally {
        setLoading(false);
      }
    };

    fetchCategoryFeed();
  }, [selectedTag]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Page Hero Header */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#17162e] via-[#121323] to-[#17162e] border border-white/10 p-6 sm:p-8">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 rounded-full bg-[#ff007a]/20 border border-[#ff007a]/40 text-[#ff007a] text-xs font-bold">
              Global YouTube Discovery
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-400 text-xs font-bold">
              <Radio className="w-3 h-3 animate-pulse text-red-500" />
              <span>Real Playable Streams</span>
            </span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-display">
            Explore All Cultural Vibrations
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
            Unfiltered pulse of African and worldwide music, cinema, haute couture, culinary artistry, and smart technology — streamable directly.
          </p>
        </div>
      </div>

      {/* Filter and Sort Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#131422] border border-white/5">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          {TAGS.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedTag === tag
                  ? 'bg-gradient-to-r from-[#ff007a] to-[#8b25ff] text-white shadow-md'
                  : 'bg-white/5 text-slate-400 hover:text-white'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-[#181a2e] border border-white/10 text-xs text-slate-200 rounded-xl px-3 py-1.5 focus:outline-none"
          >
            <option value="trending">Sort: Highest Vibe Score</option>
            <option value="recent">Sort: Most Recent</option>
            <option value="popular">Sort: Most Viewed</option>
          </select>
        </div>
      </div>

      {/* Content Grid */}
      {loading ? (
        <div className="py-12 flex flex-col items-center justify-center space-y-3">
          <Loader2 className="w-8 h-8 text-[#ff007a] animate-spin" />
          <p className="text-xs text-slate-400">Loading YouTube streams for {selectedTag}...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {items.map((item) => (
            <VideoCard
              key={item.id}
              item={item}
              onSelect={onSelectItem}
            />
          ))}
        </div>
      )}

    </div>
  );
};
