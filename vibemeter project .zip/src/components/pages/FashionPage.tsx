import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Rss, 
  Flame, 
  ShoppingBag, 
  ExternalLink, 
  Loader2,
  CheckCircle2,
  X,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Search,
  Tag,
  Share2,
  MessageSquare,
  Clock,
  Check,
  Shirt,
  DollarSign
} from 'lucide-react';
import { initializePaystackCheckout } from '../../services/paystack';
import { upvoteEditorial, getSponsoredPosts } from '../../services/firebase';
import { FASHION_EDITORIAL_DROPS } from '../../data/mockData';
import { EditorialCommentDrawer } from '../editorial/EditorialCommentDrawer';

export interface FashionArticle {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  brand: string;
  priceTag: string;
  amountInNaira: number;
  publishedAt: string;
  timeAgo: string;
  heroImageUrl: string;
  sourceName: string;
  sourceUrl: string;
  affiliateUrl: string;
  upvotes: number;
  commentsCount: number;
  tags?: string[];
}

interface FashionPageProps {
  onNavigatePromote?: () => void;
  userEmail?: string;
}

export const FashionPage: React.FC<FashionPageProps> = ({
  onNavigatePromote,
  userEmail = 'collector@vibemeter.app'
}) => {
  const [articles, setArticles] = useState<FashionArticle[]>(FASHION_EDITORIAL_DROPS);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [activeCommentArticle, setActiveCommentArticle] = useState<FashionArticle | null>(null);
  const [purchasedArticle, setPurchasedArticle] = useState<{ article: FashionArticle; reference: string } | null>(null);
  const [purchasingId, setPurchasingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});

  const fetchFashionFeed = async (isManualRefresh = false) => {
    if (isManualRefresh) setRefreshing(true);
    else setLoading(true);

    try {
      const res = await fetch(`/api/rss/feed?category=fashion&refresh=${isManualRefresh}&t=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        if (data.items && data.items.length > 0) {
          setArticles(data.items);
        }
      }
    } catch {
      // Fallback to rich curated local dataset
      setArticles(FASHION_EDITORIAL_DROPS);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchFashionFeed();
  }, []);

  const handleBuyNow = (article: FashionArticle, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!article.amountInNaira) return;
    setPurchasingId(article.id);

    initializePaystackCheckout({
      email: userEmail,
      amountInNaira: article.amountInNaira,
      reference: `fash_buy_${article.id}_${Date.now()}`,
      metadata: {
        itemTitle: article.title,
        brand: article.brand,
        category: article.category,
        source: article.sourceName,
        checkoutType: 'Fashion Drop Monetization'
      },
      onSuccess: (response) => {
        setPurchasingId(null);
        setPurchasedArticle({
          article,
          reference: response.reference
        });
      },
      onClose: () => {
        setPurchasingId(null);
      }
    });
  };

  const handleUpvote = async (articleId: string, currentCount: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (likedMap[articleId]) return;

    setLikedMap(prev => ({ ...prev, [articleId]: true }));
    setArticles(prev => prev.map(a => a.id === articleId ? { ...a, upvotes: a.upvotes + 1 } : a));

    try {
      await upvoteEditorial(articleId, currentCount);
    } catch {}
  };

  const handleShare = async (article: FashionArticle, e: React.MouseEvent) => {
    e.stopPropagation();
    const shareUrl = article.affiliateUrl || article.sourceUrl || window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: article.title,
          text: `${article.title} - ${article.priceTag}`,
          url: shareUrl
        });
        return;
      } catch {}
    }

    navigator.clipboard?.writeText(shareUrl);
    setCopiedId(article.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredArticles = articles.filter(item => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match = 
        item.title.toLowerCase().includes(q) ||
        item.subtitle.toLowerCase().includes(q) ||
        item.brand.toLowerCase().includes(q) ||
        (item.tags && item.tags.some(t => t.toLowerCase().includes(q)));
      if (!match) return false;
    }

    if (selectedFilter === 'footwear') {
      return item.category.toLowerCase().includes('footwear') || item.title.toLowerCase().includes('sneaker') || item.title.toLowerCase().includes('air max') || item.title.toLowerCase().includes('samba');
    }
    if (selectedFilter === 'runway') {
      return item.category.toLowerCase().includes('runway') || item.title.toLowerCase().includes('runway') || item.title.toLowerCase().includes('fashion week');
    }
    if (selectedFilter === 'capsule') {
      return item.category.toLowerCase().includes('capsule') || item.category.toLowerCase().includes('apparel') || item.title.toLowerCase().includes('jacket') || item.title.toLowerCase().includes('knitwear');
    }
    if (selectedFilter === 'accessories') {
      return item.category.toLowerCase().includes('accessories') || item.title.toLowerCase().includes('leather') || item.title.toLowerCase().includes('duffle');
    }
    if (selectedFilter === 'under250') {
      return item.amountInNaira <= 250000;
    }
    return true;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* 1. HYPEBEAST & VOGUE EDITORIAL LUXURY MASTHEAD (Zero Video Guaranteed) */}
      <header className="relative rounded-3xl overflow-hidden bg-black border border-white/15 p-6 sm:p-10 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-[#ff007a]/20 via-[#b026ff]/10 to-transparent blur-3xl pointer-events-none" />

        {/* Live RSS & Category Status Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-6 border-b border-white/10 relative z-10">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 rounded-full text-black font-black uppercase text-xs tracking-wider bg-white">
              HYPEBEAST · HIGHSNOBIETY · VOGUE
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
              <Rss className="w-3 h-3 text-emerald-400 animate-pulse" />
              <span>Live Fashion Pipelines Active</span>
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ff007a]/20 border border-[#ff007a]/40 text-[#ff007a] text-xs font-bold">
              <Shirt className="w-3 h-3 text-[#ff007a]" />
              <span>Pure Editorial & Retail · Zero Videos</span>
            </span>
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-300">
            <button
              onClick={() => fetchFashionFeed(true)}
              disabled={refreshing || loading}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white font-mono text-[11px] font-bold border border-white/10 transition-colors disabled:opacity-50"
              title="Pull daily live fashion updates from RSS endpoints"
            >
              <RefreshCw className={`w-3 h-3 text-[#00f2fe] ${refreshing ? 'animate-spin' : ''}`} />
              <span>{refreshing ? 'Syncing...' : 'Sync Live Feeds'}</span>
            </button>
            <span className="font-mono text-slate-400">DAILY DISPATCH</span>
            <span>·</span>
            <span className="text-[#ff007a] font-bold font-mono">
              {articles.length} Curated Drops
            </span>
          </div>
        </div>

        {/* Bold Magazine Headline */}
        <div className="mt-8 max-w-3xl space-y-3 relative z-10">
          <div className="flex items-center gap-2 text-[#ff007a] text-xs font-black uppercase tracking-widest">
            <Shirt className="w-4 h-4" />
            <span>High-End Continental Runway, Footwear Drops & Luxury Streetwear</span>
          </div>
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white font-display tracking-tight uppercase leading-none">
            The Fashion <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#ff007a] via-[#b026ff] to-[#00f2fe]">Curation</span>
          </h1>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
            Real-time editorial drops extracted directly from Hypebeast, Highsnobiety, and Vogue. Featuring direct affiliate partner links and instant Buy Now checkouts powered by Paystack.
          </p>
        </div>

        {/* Filter Controls & Search */}
        <div className="mt-8 pt-6 border-t border-white/10 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 relative z-10">
          
          {/* Filter Pills (Zero Video Option) */}
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'all', label: 'All Drops' },
              { id: 'footwear', label: '👟 Footwear & Kicks' },
              { id: 'runway', label: '✨ Runway Trends' },
              { id: 'capsule', label: '🧥 Capsule Apparel' },
              { id: 'accessories', label: '👜 Luxury Leather' },
              { id: 'under250', label: '🏷️ Under ₦250K' }
            ].map(f => (
              <button
                key={f.id}
                onClick={() => setSelectedFilter(f.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                  selectedFilter === f.id
                    ? 'bg-[#ff007a] text-white shadow-lg shadow-[#ff007a]/30'
                    : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search designer, kicks, brand..."
              className="w-full pl-9 pr-4 py-2 bg-white/5 border border-white/10 rounded-full text-xs text-white placeholder-slate-400 focus:outline-none focus:border-[#ff007a] transition-colors"
            />
          </div>
        </div>
      </header>

      {/* 2. SUCCESSFUL PURCHASE MODAL */}
      {purchasedArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="bg-[#121323] border border-emerald-500/40 rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl relative">
            <button
              onClick={() => setPurchasedArticle(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="text-center space-y-1">
              <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold">
                Order Confirmed via Paystack
              </span>
              <h3 className="text-xl font-bold text-white font-display">
                Drop Allocation Secured!
              </h3>
              <p className="text-xs text-slate-300">
                Your order for <strong className="text-white">{purchasedArticle.article.title}</strong> has been logged with reference <span className="font-mono text-emerald-300">{purchasedArticle.reference}</span>.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 space-y-2 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Brand / Atelier:</span>
                <span className="text-white font-bold">{purchasedArticle.article.brand}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Amount Paid:</span>
                <span className="text-emerald-400 font-bold font-mono">₦{purchasedArticle.article.amountInNaira?.toLocaleString()} NGN</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Dispatch Origin:</span>
                <span className="text-white">{purchasedArticle.article.sourceName} Official Store</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setPurchasedArticle(null)}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-black font-bold text-xs shadow-lg hover:opacity-95"
              >
                Return to Fashion Catalog
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. EDITORIAL MAGAZINE PRODUCT CARDS GRID */}
      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center space-y-4">
          <Loader2 className="w-10 h-10 text-[#ff007a] animate-spin" />
          <p className="text-sm font-mono text-slate-400">
            Extracting editorial streams from Hypebeast, Highsnobiety & Vogue...
          </p>
        </div>
      ) : filteredArticles.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-[#121323] border border-white/10 space-y-3">
          <p className="text-base font-bold text-white font-display">No fashion articles match your filter</p>
          <p className="text-xs text-slate-400">Try clearing your search query or selecting "All Drops".</p>
          <button
            onClick={() => { setSelectedFilter('all'); setSearchQuery(''); }}
            className="px-4 py-2 rounded-xl bg-white/10 text-white text-xs font-bold hover:bg-white/20"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.map((article) => {
            const isLiked = Boolean(likedMap[article.id]);
            const isPurchasing = purchasingId === article.id;
            const isCopied = copiedId === article.id;

            return (
              <article 
                key={article.id}
                className="group bg-[#111222] border border-white/10 hover:border-[#ff007a]/40 rounded-3xl overflow-hidden transition-all duration-300 hover:shadow-2xl hover:shadow-[#ff007a]/15 flex flex-col justify-between"
              >
                
                {/* Media Hero Cover (High-Res Editorial Photography - ZERO Videos) */}
                <div className="relative aspect-[16/10] bg-black overflow-hidden">
                  <img
                    src={article.heroImageUrl}
                    alt={article.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />

                  {/* Gradient Scrim */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111222] via-transparent to-black/50 pointer-events-none" />

                  {/* Category Pill (Top Left) */}
                  <div className="absolute top-3 left-3 flex items-center gap-1.5">
                    <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-black/80 backdrop-blur-md text-[#ff007a] border border-[#ff007a]/40 shadow-lg">
                      {article.category}
                    </span>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-white/10 backdrop-blur-md text-white border border-white/10">
                      {article.sourceName}
                    </span>
                  </div>

                  {/* Timestamp (Top Right) */}
                  <div className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-white text-[10px] font-mono border border-white/10">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span>{article.timeAgo}</span>
                  </div>
                </div>

                {/* Card Editorial Body */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    
                    {/* Brand / Atelier Header */}
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      <span className="text-[#00f2fe]">{article.brand}</span>
                      <span className="text-slate-400 font-mono text-[10px]">Verified Drop</span>
                    </div>

                    {/* Headline */}
                    <h2 className="text-lg font-extrabold text-white font-display leading-tight group-hover:text-[#ff007a] transition-colors">
                      {article.title}
                    </h2>

                    {/* Editorial Excerpt */}
                    <p className="text-xs text-slate-300 leading-relaxed line-clamp-3">
                      {article.subtitle}
                    </p>
                  </div>

                  {/* Retail Drop Price Tag & Monetization CTA Buttons */}
                  <div className="pt-3 border-t border-white/5 space-y-3">
                    
                    {/* Price and Badge */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Tag className="w-3.5 h-3.5 text-[#00f2fe]" />
                        <div>
                          <span className="text-[9px] uppercase font-bold text-slate-400 block">Retail Value</span>
                          <span className="text-xs sm:text-sm font-extrabold text-[#00f2fe] font-mono">
                            {article.priceTag || '₦185,000 / $120 USD'}
                          </span>
                        </div>
                      </div>

                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 text-[10px] font-mono font-bold border border-emerald-500/20">
                        In Stock
                      </span>
                    </div>

                    {/* Action Buttons: 1. Native Paystack Buy Now CTA, 2. Outbound Affiliate Shop Link */}
                    <div className="grid grid-cols-2 gap-2">
                      
                      {/* BUY NOW CTA Button */}
                      <button
                        onClick={(e) => handleBuyNow(article, e)}
                        disabled={isPurchasing}
                        className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#ff007a] to-[#8b25ff] hover:opacity-95 text-white font-extrabold text-xs shadow-md shadow-[#ff007a]/25 flex items-center justify-center gap-1.5 transition-transform active:scale-95 disabled:opacity-50"
                      >
                        {isPurchasing ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <ShoppingBag className="w-3.5 h-3.5" />
                        )}
                        <span>{isPurchasing ? 'Securing...' : 'Buy Now'}</span>
                      </button>

                      {/* Outbound Affiliate Partner Link */}
                      <a
                        href={article.affiliateUrl || article.sourceUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/10 flex items-center justify-center gap-1.5 transition-all text-center"
                        title="Shop directly on partner retailer with affiliate attribution"
                      >
                        <ExternalLink className="w-3.5 h-3.5 text-[#00f2fe]" />
                        <span>Shop Drop</span>
                      </a>
                    </div>

                  </div>

                  {/* Tags */}
                  {article.tags && article.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {article.tags.slice(0, 3).map((t, idx) => (
                        <span key={idx} className="text-[10px] font-medium text-slate-400 bg-white/5 px-2 py-0.5 rounded-md">
                          #{t}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Bottom Social Toolbar */}
                <div className="px-5 py-3 bg-[#141528] border-t border-white/5 flex items-center justify-between text-xs">
                  
                  {/* Upvote */}
                  <button
                    onClick={(e) => handleUpvote(article.id, article.upvotes, e)}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold transition-all ${
                      isLiked
                        ? 'bg-[#ff007a] text-white'
                        : 'bg-white/5 hover:bg-white/10 text-slate-300'
                    }`}
                  >
                    <Flame className={`w-3.5 h-3.5 ${isLiked ? 'fill-white text-white' : 'text-[#ff007a]'}`} />
                    <span>{article.upvotes}</span>
                  </button>

                  <div className="flex items-center gap-2">
                    {/* Comments */}
                    <button
                      onClick={() => setActiveCommentArticle(article)}
                      className="inline-flex items-center gap-1 text-slate-400 hover:text-white px-2 py-1 rounded-lg hover:bg-white/5 transition-colors"
                      title="Open drop discussions"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>{article.commentsCount}</span>
                    </button>

                    {/* Share */}
                    <button
                      onClick={(e) => handleShare(article, e)}
                      className="inline-flex items-center gap-1 text-slate-400 hover:text-[#00f2fe] px-2 py-1 rounded-lg hover:bg-white/5 transition-colors"
                      title="Share link"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                </div>

              </article>
            );
          })}
        </div>
      )}

      {/* 4. SPONSORED PROMOTED DROP BANNER */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-[#17162e] via-[#1a1738] to-[#121323] border border-[#ff007a]/30 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#ff007a]/20 border border-[#ff007a]/40 flex items-center justify-center text-[#ff007a] shrink-0">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm sm:text-base font-bold text-white font-display">
              Are you a Fashion Designer, Streetwear Label, or Brand?
            </h4>
            <p className="text-xs text-slate-300 mt-0.5">
              Promote your product drop or runway story directly to VibeMeter's cultural readership with Paystack inline checkout.
            </p>
          </div>
        </div>

        {onNavigatePromote && (
          <button
            onClick={onNavigatePromote}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#ff007a] to-[#8b25ff] hover:opacity-95 text-white font-bold text-xs shadow-lg shadow-[#ff007a]/25 shrink-0 flex items-center gap-2"
          >
            <span>Promote Sponsored Story</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* 5. COMMENT DRAWER */}
      {activeCommentArticle && (
        <EditorialCommentDrawer
          isOpen={true}
          articleId={activeCommentArticle.id}
          articleTitle={activeCommentArticle.title}
          initialCommentsCount={activeCommentArticle.commentsCount || 0}
          onClose={() => setActiveCommentArticle(null)}
        />
      )}

    </div>
  );
};
