import React, { useState } from 'react';
import { 
  Sparkles, 
  Upload, 
  CheckCircle2, 
  ShieldCheck, 
  CreditCard, 
  Radio, 
  ExternalLink,
  ArrowRight,
  Loader2,
  Tag,
  Zap,
  Flame
} from 'lucide-react';
import { initializePaystackCheckout, getPaystackPublicKey } from '../../services/paystack';
import { saveSponsoredPost } from '../../services/firebase';
import { PROMOTE_POST_CONFIG } from '../../data/mockData';

interface PromotePostPageProps {
  onNavigateCategory?: (category: string) => void;
}

export const PromotePostPage: React.FC<PromotePostPageProps> = ({
  onNavigateCategory
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Fashion');
  const [mediaUrl, setMediaUrl] = useState('');
  const [creatorName, setCreatorName] = useState('');
  const [email, setEmail] = useState('brand@vibemeter.app');
  const [linkUrl, setLinkUrl] = useState('');
  const [description, setDescription] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<{ name: string; amount: number; duration: string }>({
    name: PROMOTE_POST_CONFIG.feature,
    amount: PROMOTE_POST_CONFIG.amount_pennies / 100,
    duration: '24 Hours Editorial Spotlight'
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [promotedSuccess, setPromotedSuccess] = useState<{ post: any; reference: string } | null>(null);

  const PLANS = [
    {
      name: PROMOTE_POST_CONFIG.feature,
      amount: PROMOTE_POST_CONFIG.amount_pennies / 100, // 10,000 NGN (1,000,000 pennies)
      duration: '24 Hours',
      badge: 'Official Parameter Spec',
      displayPrice: PROMOTE_POST_CONFIG.display_price,
      description: 'Top spotlight placement across editorial magazine feeds & home ticker via @paystack/inline-js.'
    },
    {
      name: '3-Day Category Spotlight',
      amount: 25000,
      duration: '3 Days',
      badge: 'Extended Reach',
      displayPrice: '₦25,000',
      description: 'Pinned placement in editorial magazine listing + homepage featured section.'
    },
    {
      name: '7-Day VIP Domination',
      amount: 50000,
      duration: '7 Days',
      displayPrice: '₦50,000',
      description: 'Maximum reach across Fashion, Music, and Tech discovery feeds.'
    }
  ];

  const handlePromoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !mediaUrl.trim() || !email.trim()) return;

    setIsProcessing(true);

    initializePaystackCheckout({
      email: email.trim(),
      amountInNaira: selectedPlan.amount,
      reference: `sponsor_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      metadata: {
        title: title.trim(),
        category,
        creatorName: creatorName.trim(),
        plan: selectedPlan.name
      },
      onSuccess: async (response) => {
        try {
          const savedPost = await saveSponsoredPost({
            title: title.trim(),
            category,
            mediaUrl: mediaUrl.trim(),
            creator: creatorName.trim() || 'Verified Brand Partner',
            description: description.trim(),
            linkUrl: linkUrl.trim(),
            amountPaid: selectedPlan.amount,
            paymentReference: response.reference
          });

          setPromotedSuccess({
            post: savedPost,
            reference: response.reference
          });
        } catch (err) {
          console.warn('Sponsored post save error:', err);
        } finally {
          setIsProcessing(false);
        }
      },
      onClose: () => {
        setIsProcessing(false);
      }
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="p-6 sm:p-10 rounded-3xl bg-gradient-to-r from-[#17162e] via-[#1a1738] to-[#121323] border border-[#ff007a]/30 shadow-2xl relative overflow-hidden">
        <div className="max-w-2xl space-y-3 relative z-10">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-[#ff007a]/20 border border-[#ff007a]/40 text-[#ff007a] text-xs font-black uppercase">
              Creator & Brand Sponsorship
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>Paystack Secured</span>
            </span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-white font-display">
            Promote Your Story or Product Drop
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed">
            Gain immediate exposure across VibeMeter’s editorial magazine feeds. Verified placements in Fashion, Music, and Tech with real-time analytics.
          </p>
        </div>
      </div>

      {/* Success Receipt State */}
      {promotedSuccess ? (
        <div className="p-8 rounded-3xl bg-[#131424] border border-emerald-500/40 text-center space-y-5 shadow-2xl animate-in zoom-in-95">
          <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto text-emerald-400">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-1">
            <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest">
              Paystack Transaction Verified
            </span>
            <h2 className="text-2xl font-bold text-white font-display">
              Post Promoted Successfully!
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto">
              Your story has been saved to Firebase Firestore with <strong className="text-white">featured: true</strong> and is now live on VibeMeter™.
            </p>
          </div>

          <div className="max-w-md mx-auto p-4 rounded-2xl bg-[#181a2e] border border-white/5 text-left text-xs space-y-2 font-mono">
            <div className="flex justify-between text-slate-400">
              <span>Title:</span>
              <span className="text-white truncate max-w-[200px]">{promotedSuccess.post.title}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Category:</span>
              <span className="text-[#ff007a] font-bold">{promotedSuccess.post.category}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Payment Ref:</span>
              <span className="text-emerald-400 truncate max-w-[200px]">{promotedSuccess.reference}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Amount Paid:</span>
              <span className="text-white font-bold">₦{promotedSuccess.post.amountPaid?.toLocaleString()} NGN</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => {
                if (onNavigateCategory) {
                  onNavigateCategory(`/${promotedSuccess.post.category.toLowerCase()}`);
                }
              }}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#ff007a] to-[#8b25ff] text-white text-xs font-bold flex items-center gap-2"
            >
              <span>View in {promotedSuccess.post.category} Feed</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => {
                setPromotedSuccess(null);
                setTitle('');
                setMediaUrl('');
              }}
              className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold"
            >
              Promote Another Post
            </button>
          </div>
        </div>
      ) : (
        /* Form & Plan Selection */
        <form onSubmit={handlePromoteSubmit} className="space-y-6">
          
          {/* Plan Selector */}
          <div className="space-y-3">
            <label className="text-xs font-bold text-white uppercase tracking-wider block">
              1. Select Promotion Duration & Tier
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {PLANS.map((plan) => {
                const isSelected = selectedPlan.name === plan.name;
                return (
                  <div
                    key={plan.name}
                    onClick={() => setSelectedPlan(plan)}
                    className={`p-4 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between relative ${
                      isSelected
                        ? 'bg-[#1b1c36] border-[#ff007a] shadow-lg shadow-[#ff007a]/20 scale-[1.02]'
                        : 'bg-[#131422] border-white/10 hover:border-white/20'
                    }`}
                  >
                    {plan.badge && (
                      <span className="absolute -top-2.5 right-3 px-2 py-0.5 rounded-full bg-gradient-to-r from-[#ff007a] to-[#8b25ff] text-white text-[9px] font-black uppercase shadow">
                        {plan.badge}
                      </span>
                    )}

                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{plan.duration}</span>
                        <Radio className={`w-4 h-4 ${isSelected ? 'text-[#ff007a]' : 'text-slate-500'}`} />
                      </div>
                      <div className="text-lg font-black text-white font-mono mt-2">
                        ₦{plan.amount.toLocaleString()}
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                        {plan.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Form Fields */}
          <div className="p-6 sm:p-8 rounded-3xl bg-[#131422] border border-white/10 space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-2 border-b border-white/10">
              2. Story & Media Specifications
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Headline / Title *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Ashluxe Drops SS25 Cyber-Heritage Collection"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#181a2e] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Target Category *
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-[#181a2e] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
                >
                  <option value="Fashion">Fashion & Luxury Streetwear</option>
                  <option value="Business">Business & Tech Startups</option>
                  <option value="Music">Music & Afrobeats</option>
                  <option value="Tech">Tech & Gadgets</option>
                  <option value="Lifestyle">Lifestyle & Wellness</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Cover Image or Video Thumbnail URL *
                </label>
                <input
                  type="url"
                  required
                  value={mediaUrl}
                  onChange={(e) => setMediaUrl(e.target.value)}
                  placeholder="https://i.ytimg.com/vi/bB9_e5Vp-Yw/hqdefault.jpg"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#181a2e] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Creator / Brand Name *
                </label>
                <input
                  type="text"
                  required
                  value={creatorName}
                  onChange={(e) => setCreatorName(e.target.value)}
                  placeholder="e.g. Daily Paper, Ashluxe, TechCabal"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#181a2e] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Customer Email (for Paystack Receipt) *
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="brand@example.com"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#181a2e] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Destination URL / Shop Link
                </label>
                <input
                  type="url"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  placeholder="https://yourbrand.com/drop"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#181a2e] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Story Excerpt / Pitch Description
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Brief summary of why this collection or announcement matters to culture..."
                className="w-full p-3 rounded-xl bg-[#181a2e] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
              />
            </div>

            {/* Paystack Checkout Button */}
            <div className="pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-white/10">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <CreditCard className="w-4 h-4 text-[#00f2fe]" />
                <span>Secured via Paystack Inline Pop-up Gateway</span>
              </div>

              <button
                type="submit"
                disabled={isProcessing}
                className="px-8 py-3.5 rounded-full bg-gradient-to-r from-[#ff007a] via-[#ff2e93] to-[#8b25ff] hover:opacity-95 text-white font-extrabold text-sm shadow-xl shadow-[#ff007a]/30 flex items-center justify-center gap-2 transition-transform active:scale-95 disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Processing Checkout...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 fill-white" />
                    <span>Promote Post via Paystack (₦{selectedPlan.amount.toLocaleString()})</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </form>
      )}

    </div>
  );
};
