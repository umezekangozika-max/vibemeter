import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Rss, 
  Flame, 
  ShoppingBag, 
  TrendingUp, 
  Briefcase, 
  Shirt, 
  ExternalLink, 
  Radio, 
  Loader2,
  CheckCircle2,
  X,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Search,
  Tag
} from 'lucide-react';
import { EditorialMagazineCard, EditorialArticle } from './EditorialMagazineCard';
import { EditorialCommentDrawer } from './EditorialCommentDrawer';
import { getSponsoredPosts } from '../../services/firebase';

interface EditorialMagazineViewProps {
  categoryType: 'fashion' | 'business';
  onPlayVideo?: (youtubeId: string, title: string) => void;
  onNavigatePromote?: () => void;
}

export const EditorialMagazineView: React.FC<EditorialMagazineViewProps> = ({
  categoryType,
  onPlayVideo,
  onNavigatePromote
}) => {
  const isFashion = categoryType === 'fashion';
  const [articles, setArticles] = useState<EditorialArticle[]>([]);
  const [sponsored, setSponsored] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [feedSourceInfo, setFeedSourceInfo] = useState<{ source?: string; youtubeQuery?: string; totalItems?: number }>({});
  const [activeCommentArticle, setActiveCommentArticle] = useState<EditorialArticle | null>(null);
  const [purchasedArticle, setPurchasedArticle] = useState<{ article: EditorialArticle; reference: string } | null>(null);
  const [activeFilter, setActiveFilter] = useState<'all' | 'video' | 'priced'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const fetchEditorialFeed = async (isManualRefresh = false) => {
    if (isManualRefresh) setRefreshing(true);
    else setLoading(true);

    try {
      const [feedRes, sponsoredList] = await Promise.all([
        fetch(`/api/rss/feed?category=${categoryType}&t=${Date.now()}`),
        getSponsoredPosts(categoryType)
      ]);

      if (feedRes.ok) {
        const data = await feedRes.json();
        if (data.items && data.items.length > 0) {
          setArticles(data.items);
          setFeedSourceInfo({
            source: data.source,
            youtubeQuery: data.youtubeQuery,
            totalItems: data.totalItems
          });
        }
      }
      setSponsored(sponsoredList || []);
    } catch (err) {
      console.warn('Editorial feed fetch notice:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchEditorialFeed();
  }, [categoryType]);

  const handlePurchaseSuccess = (article: EditorialArticle, reference: string) => {
    setPurchasedArticle({ article, reference });
  };

  const filteredArticles = articles.filter(article => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchesSearch = 
        article.title.toLowerCase().includes(q) ||
        article.subtitle.toLowerCase().includes(q) ||
        (article.brand && article.brand.toLowerCase().includes(q)) ||
        (article.tags && article.tags.some(t => t.toLowerCase().includes(q)));
      if (!matchesSearch) return false;
    }

    if (activeFilter === 'video') {
      return Boolean(article.youtubeId);
    }
    if (activeFilter === 'priced') {
      return Boolean(article.priceTag && (article.amountInNaira || 0) > 0);
    }
    return true;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* 1. Hypebeast-Style Editorial Magazine Banner */}
      <header className="relative rounded-3xl overflow-hidden bg-black border border-white/15 p-6 sm:p-10 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-[#ff007a]/20 via-[#00f2fe]/10 to-transparent blur-3xl pointer-events-none" />

        {/* Live RSS & Category Status Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-6 border-b border-white/10 relative z-10">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 rounded-full text-black font-black uppercase text-xs tracking-wider bg-white">
              {isFashion ? 'HYPEBEAST & HIGHSNOBIETY' : 'CNBC BUSINESS & ENTREPRENEUR'}
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/40 text-red-400 text-xs font-bold">
              <Rss className="w-3 h-3 text-red-500 animate-pulse" />
              <span>Live RSS Feeds Active</span>
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-600/20 border border-blue-500/40 text-blue-300 text-xs font-bold">
              <Radio className="w-3 h-3 text-blue-400 animate-pulse" />
              <span>YT: "{isFashion ? 'streetwear fashion drops' : 'startup business trends'}"</span>
            </span>
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-300">
            <button
              onClick={() => fetchEditorialFeed(true)}
              disabled={refreshing || loading}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white font-mono text-[11px] font-bold border border-white/10 transition-colors disabled:opacity-50"
              title="Pull daily live updates from RSS endpoints"
            >
              <RefreshCw className={`w-3 h-3 text-[#00f2fe] ${refreshing ? 'animate-spin' : ''}`} />
              <span>{refreshing ? 'Updating...' : 'Sync Live Feeds'}</span>
            </button>
            <span className="font-mono text-slate-400">DAILY DISPATCH</span>
            <span>·</span>
            <span className="text-[#00f2fe] font-bold">
              {articles.length} Live Items
            </span>
          </div>
        </div>

        {/* Big Bold Magazine Headline */}
        <div className="mt-8 max-w-3xl space-y-3 relative z-10">
          <div className="flex items-center gap-2 text-[#ff007a] text-xs font-black uppercase tracking-widest">
            {isFashion ? (
              <>
                <Shirt className="w-4 h-4" />
                <span>Hypebeast RSS (https://hypebeast.com/feed) & Highsnobiety Feed · Streetwear Drops</span>
              </>
            ) : (
              <>
                <Briefcase className="w-4 h-4" />
                <span>CNBC Business RSS (combinedcms) & Entrepreneur RSS · Startup Trends</span>
              </>
            )}
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white font-display tracking-tight leading-none uppercase">
            {isFashion ? 'The Style Dossier & Drops' : 'The Venture & Markets Brief'}
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
            {isFashion
              ? 'Real-time coverage pulling directly from Hypebeast and Highsnobiety feeds, combined with active YouTube search queries for "streetwear fashion drops" and direct Paystack checkout.'
              : 'Direct market intelligence pulling from CNBC Business combined CMS and Entrepreneur RSS, merged with verified YouTube queries for "startup business trends".'}
          </p>
        </div>

        {/* Promote Post CTA Strip */}
        <div className="mt-8 pt-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <Sparkles className="w-4 h-4 text-[#ff007a]" />
            <span>Are you a designer or startup founder? Promote your story to 50K+ readers.</span>
          </div>

          <button
            onClick={onNavigatePromote}
            className="px-5 py-2.5 rounded-full bg-gradient-to-r from-[#ff007a] to-[#8b25ff] hover:opacity-95 text-white font-extrabold text-xs shadow-lg shadow-[#ff007a]/30 flex items-center gap-1.5 transition-transform active:scale-95"
          >
            <span>Promote Sponsored Story (₦10,000)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* 2. Sponsored Features Spotlight if present */}
      {sponsored.length > 0 && (
        <section className="p-4 rounded-3xl bg-gradient-to-r from-[#17142b] via-[#111222] to-[#17142b] border border-[#ff007a]/30">
          <div className="flex items-center justify-between mb-3 px-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-[#ff007a] text-white text-[10px] font-black uppercase">
                SPONSORED SPOTLIGHT
              </span>
              <span className="text-xs text-slate-300 font-semibold">Verified Brand Partner</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">24-Hr Feature</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {sponsored.map((post) => (
              <div 
                key={post.id}
                className="p-3.5 rounded-2xl bg-[#16172d] border border-white/10 flex gap-4 items-center"
              >
                <img
                  src={post.mediaUrl}
                  alt={post.title}
                  className="w-24 h-20 rounded-xl object-cover shrink-0"
                />
                <div className="min-w-0 flex-1 space-y-1">
                  <span className="text-[10px] font-bold text-[#ff007a] uppercase">{post.creator}</span>
                  <h4 className="text-xs font-bold text-white truncate">{post.title}</h4>
                  <p className="text-[11px] text-slate-400 line-clamp-2">{post.description}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 3. Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-[#111222] border border-white/10 p-3 rounded-2xl">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeFilter === 'all'
                ? 'bg-white text-black'
                : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
            }`}
          >
            All Dispatch ({articles.length})
          </button>
          <button
            onClick={() => setActiveFilter('video')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeFilter === 'video'
                ? 'bg-[#ff007a] text-white'
                : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
            }`}
          >
            <Radio className="w-3 h-3" />
            <span>Playable Video Covers</span>
          </button>
          {isFashion && (
            <button
              onClick={() => setActiveFilter('priced')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeFilter === 'priced'
                  ? 'bg-[#00f2fe] text-black font-extrabold'
                  : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
              }`}
            >
              <Tag className="w-3 h-3" />
              <span>Retail Drops & Purchases</span>
            </button>
          )}
        </div>

        <div className="relative min-w-[200px]">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Filter ${isFashion ? 'drops, sneakers, brands...' : 'startups, funding, trends...'}`}
            className="w-full bg-[#181930] border border-white/10 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-[#ff007a]"
          />
        </div>
      </div>

      {/* 4. Magazine Articles Grid */}
      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center space-y-3">
          <Loader2 className="w-8 h-8 text-[#ff007a] animate-spin" />
          <p className="text-xs text-slate-400">
            {isFashion 
              ? 'Parsing daily items from Hypebeast & Highsnobiety feeds with YouTube streetwear video streams...' 
              : 'Parsing daily updates from CNBC Business & Entrepreneur feeds with YouTube startup trends...'}
          </p>
        </div>
      ) : filteredArticles.length === 0 ? (
        <div className="py-16 text-center rounded-3xl bg-[#111222] border border-white/10 space-y-3">
          <p className="text-sm font-bold text-white">No articles matching your current filter.</p>
          <button
            onClick={() => { setActiveFilter('all'); setSearchQuery(''); }}
            className="px-4 py-2 rounded-xl bg-white/10 text-xs font-bold text-white hover:bg-white/20"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredArticles.map((article) => (
            <EditorialMagazineCard
              key={article.id}
              article={article}
              onOpenComments={(art) => setActiveCommentArticle(art)}
              onPlayVideo={onPlayVideo}
              onPurchaseSuccess={handlePurchaseSuccess}
            />
          ))}
        </div>
      )}

      {/* 5. Live Comment Drawer */}
      <EditorialCommentDrawer
        isOpen={Boolean(activeCommentArticle)}
        onClose={() => setActiveCommentArticle(null)}
        articleId={activeCommentArticle?.id || ''}
        articleTitle={activeCommentArticle?.title || ''}
        initialCommentsCount={activeCommentArticle?.commentsCount || 0}
      />

      {/* 6. Paystack Purchase Success Receipt Modal */}
      {purchasedArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-md bg-[#131424] border border-white/10 rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto text-emerald-400">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-widest">
                Paystack Payment Verified
              </span>
              <h3 className="text-lg font-bold text-white font-display">
                Drop Order Confirmed!
              </h3>
              <p className="text-xs text-slate-300">
                You have successfully ordered <strong className="text-white">{purchasedArticle.article.title}</strong>.
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#191a2e] border border-white/5 text-left text-xs space-y-1.5 font-mono">
              <div className="flex justify-between text-slate-400">
                <span>Transaction Ref:</span>
                <span className="text-white truncate max-w-[180px]">{purchasedArticle.reference}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Amount Settled:</span>
                <span className="text-[#00f2fe] font-bold">₦{purchasedArticle.article.amountInNaira?.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Merchant:</span>
                <span className="text-white">VibeMeter™ Retail Gateway</span>
              </div>
            </div>

            <button
              onClick={() => setPurchasedArticle(null)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#ff007a] to-[#8b25ff] text-white text-xs font-bold"
            >
              Continue Exploring Drops
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
