import React, { useState } from 'react';
import { 
  ExternalLink, 
  Flame, 
  Share2, 
  Check, 
  Bookmark, 
  Clock, 
  BookOpen,
  ArrowUpRight
} from 'lucide-react';

export interface EditorialCardData {
  id: string;
  title: string;
  subtitle?: string;
  description: string;
  category: string;
  readTime?: string;
  publishedAt: string;
  timeAgo?: string;
  heroImageUrl: string;
  sourceName: string;
  sourceUrl: string;
  tags?: string[];
  markdownContent?: string;
  upvotes?: number;
  author?: {
    name: string;
    role?: string;
    avatar?: string;
  };
}

interface EditorialMarkdownCardProps {
  article: EditorialCardData;
  onSelect?: (article: EditorialCardData) => void;
}

export const EditorialMarkdownCard: React.FC<EditorialMarkdownCardProps> = ({ article, onSelect }) => {
  const [upvotes, setUpvotes] = useState(article.upvotes || 420);
  const [isUpvoted, setIsUpvoted] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleUpvote = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isUpvoted) return;
    setIsUpvoted(true);
    setUpvotes(prev => prev + 1);
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const shareUrl = article.sourceUrl || window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: article.title,
          text: article.subtitle || article.description,
          url: shareUrl
        });
        return;
      } catch {}
    }

    navigator.clipboard?.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSave = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsSaved(prev => !prev);
  };

  // Helper to parse and format simple markdown chunks (paragraphs, bullets, quotes)
  const renderMarkdownBody = (content: string) => {
    const lines = content.split('\n').filter(Boolean);
    return lines.map((line, idx) => {
      const trimmed = line.trim();
      if (trimmed.startsWith('###')) {
        return (
          <h4 key={idx} className="text-sm font-bold text-white mt-2 mb-1">
            {trimmed.replace(/^###\s*/, '')}
          </h4>
        );
      }
      if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
        return (
          <li key={idx} className="text-xs text-slate-300 ml-4 list-disc marker:text-[#00f2fe] leading-relaxed">
            {trimmed.replace(/^[-*]\s*/, '')}
          </li>
        );
      }
      if (trimmed.startsWith('>')) {
        return (
          <blockquote key={idx} className="pl-3 py-1 my-2 border-l-2 border-[#00f2fe] bg-white/[0.02] text-xs italic text-slate-200 rounded-r-lg">
            {trimmed.replace(/^>\s*/, '')}
          </blockquote>
        );
      }
      return (
        <p key={idx} className="text-xs text-slate-300 leading-relaxed my-1">
          {trimmed}
        </p>
      );
    });
  };

  const domain = (() => {
    try {
      return new URL(article.sourceUrl).hostname.replace('www.', '');
    } catch {
      return article.sourceName.toLowerCase().replace(/\s+/g, '') + '.com';
    }
  })();

  return (
    <article 
      onClick={() => onSelect?.(article)}
      className="group flex flex-col bg-[#131422] rounded-3xl border border-white/10 hover:border-white/20 transition-all duration-300 overflow-hidden shadow-xl hover:shadow-2xl hover:shadow-[#00f2fe]/5 cursor-pointer"
    >
      
      {/* 1. Visual Card Header (Strictly Zero Play Buttons / Zero Video Overlays) */}
      <div className="relative aspect-[16/10] w-full overflow-hidden bg-slate-900">
        <img
          src={article.heroImageUrl}
          alt={article.title}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />

        <div className="absolute inset-0 bg-gradient-to-t from-[#131422] via-[#131422]/20 to-transparent" />

        {/* Top Badges */}
        <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between gap-2 z-10 pointer-events-none">
          <span className="px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/15 text-white text-[11px] font-bold tracking-wide flex items-center gap-1.5 shadow-md">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00f2fe]" />
            <span>{article.category}</span>
          </span>

          <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-slate-300 text-[10px] font-medium flex items-center gap-1 shadow-md">
            <Clock className="w-3 h-3 text-[#00f2fe]" />
            <span>{article.readTime || '3 min read'}</span>
          </span>
        </div>

        {/* Source Badge Tag on Bottom Edge */}
        <div className="absolute bottom-3 left-3.5 z-10">
          {onSelect ? (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onSelect(article);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-black/75 hover:bg-[#00f2fe] text-slate-200 hover:text-black border border-white/15 hover:border-[#00f2fe] text-[11px] font-bold transition-all shadow-lg group/source"
              title={`Read full article on ${domain}`}
            >
              <span>{article.sourceName}</span>
              <BookOpen className="w-3 h-3 text-[#00f2fe] group-hover/source:text-black" />
            </button>
          ) : (
            <a
              href={article.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-black/75 hover:bg-[#00f2fe] text-slate-200 hover:text-black border border-white/15 hover:border-[#00f2fe] text-[11px] font-bold transition-all shadow-lg group/source"
              title={`View official editorial on ${domain}`}
            >
              <span>{article.sourceName}</span>
              <ExternalLink className="w-3 h-3 transition-transform group-hover/source:translate-x-0.5 group-hover/source:-translate-y-0.5" />
            </a>
          )}
        </div>
      </div>

      {/* 2. Editorial Text & Markdown Content Body */}
      <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-4">
        
        <div className="space-y-3">
          {/* Published Time & Source Pill */}
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-300">{article.publishedAt}</span>
              <span>•</span>
              <span className="text-slate-400">{article.timeAgo || 'Curated'}</span>
            </div>

            <span className="text-[#00f2fe] font-mono text-[10px] flex items-center gap-1">
              <span>{domain}</span>
            </span>
          </div>

          {/* Editorial Title */}
          <h3 className="text-base sm:text-lg font-bold text-white font-display leading-snug group-hover:text-[#00f2fe] transition-colors">
            {onSelect ? (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelect(article);
                }}
                className="text-left hover:underline text-white group-hover:text-[#00f2fe] transition-colors"
              >
                {article.title}
              </button>
            ) : (
              <a
                href={article.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:underline"
              >
                {article.title}
              </a>
            )}
          </h3>

          {/* Subtitle / Teaser */}
          {article.subtitle && (
            <p className="text-xs font-medium text-slate-300 leading-relaxed line-clamp-2">
              {article.subtitle}
            </p>
          )}

          {/* Formatted Markdown Content / Description Block */}
          <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/5 space-y-1">
            {article.markdownContent ? (
              renderMarkdownBody(article.markdownContent)
            ) : (
              <p className="text-xs text-slate-300 leading-relaxed line-clamp-4">
                {article.description}
              </p>
            )}
          </div>

          {/* Tags */}
          {article.tags && article.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {article.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-0.5 rounded-lg bg-white/5 text-[10px] text-slate-400 font-medium border border-white/5"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* 3. In-App Interactive Reader Button & Engagement Footer */}
        <div className="pt-4 border-t border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          {/* Functional In-App / Outbound Source Link Button */}
          {onSelect ? (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onSelect(article);
              }}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-white/10 to-white/5 hover:from-[#00f2fe]/20 hover:to-blue-600/20 text-white hover:text-[#00f2fe] border border-white/10 hover:border-[#00f2fe]/40 text-xs font-bold transition-all shadow-md group/btn"
            >
              <BookOpen className="w-3.5 h-3.5 text-[#00f2fe]" />
              <span>Read on {article.sourceName}</span>
            </button>
          ) : (
            <a
              href={article.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-white/10 to-white/5 hover:from-[#00f2fe]/20 hover:to-blue-600/20 text-white hover:text-[#00f2fe] border border-white/10 hover:border-[#00f2fe]/40 text-xs font-bold transition-all shadow-md group/btn"
            >
              <BookOpen className="w-3.5 h-3.5 text-[#00f2fe]" />
              <span>Read on {article.sourceName}</span>
              <ExternalLink className="w-3.5 h-3.5 transition-transform group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5" />
            </a>
          )}

          {/* Social / Engagement Actions */}
          <div className="flex items-center gap-1.5 self-end sm:self-auto">
            {/* Upvote */}
            <button
              onClick={handleUpvote}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                isUpvoted
                  ? 'bg-rose-500/20 border-rose-500/40 text-rose-400'
                  : 'bg-white/5 border-white/5 text-slate-400 hover:text-white hover:bg-white/10'
              }`}
              title="Upvote story"
            >
              <Flame className={`w-3.5 h-3.5 ${isUpvoted ? 'fill-rose-500 text-rose-500' : ''}`} />
              <span className="font-mono text-[11px]">{upvotes}</span>
            </button>

            {/* Save / Bookmark */}
            <button
              onClick={handleSave}
              className={`p-2 rounded-xl text-xs border transition-all ${
                isSaved
                  ? 'bg-[#00f2fe]/20 border-[#00f2fe]/40 text-[#00f2fe]'
                  : 'bg-white/5 border-white/5 text-slate-400 hover:text-white hover:bg-white/10'
              }`}
              title={isSaved ? 'Saved in collection' : 'Save story'}
            >
              <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-[#00f2fe]' : ''}`} />
            </button>

            {/* Share */}
            <button
              onClick={handleShare}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/5 transition-all relative"
              title="Share article"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
              {copiedLink && (
                <span className="absolute -top-7 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded bg-emerald-500 text-black text-[10px] font-bold whitespace-nowrap shadow-md">
                  Copied!
                </span>
              )}
            </button>
          </div>

        </div>

      </div>

    </article>
  );
};
