import React, { useState } from 'react';
import { 
  Flame, 
  MessageSquare, 
  Share2, 
  Play, 
  ExternalLink, 
  Tag, 
  ShoppingBag, 
  Check, 
  Clock, 
  X,
  Radio,
  Sparkles
} from 'lucide-react';
import { upvoteEditorial } from '../../services/firebase';
import { initializePaystackCheckout } from '../../services/paystack';

export interface EditorialArticle {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  brand?: string;
  priceTag?: string;
  amountInNaira?: number;
  publishedAt: string;
  timeAgo: string;
  heroImageUrl: string;
  youtubeId?: string;
  sourceName?: string;
  sourceUrl?: string;
  upvotes: number;
  commentsCount: number;
  tags?: string[];
}

interface EditorialMagazineCardProps {
  article: EditorialArticle;
  onOpenComments: (article: EditorialArticle) => void;
  onPlayVideo?: (youtubeId: string, title: string) => void;
  onPurchaseSuccess?: (article: EditorialArticle, reference: string) => void;
  userEmail?: string;
}

export const EditorialMagazineCard: React.FC<EditorialMagazineCardProps> = ({
  article,
  onOpenComments,
  onPlayVideo,
  onPurchaseSuccess,
  userEmail = 'collector@vibemeter.app'
}) => {
  const [upvotes, setUpvotes] = useState(article.upvotes);
  const [isUpvoted, setIsUpvoted] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isPlayingInline, setIsPlayingInline] = useState(false);
  const [isPurchasing, setIsPurchasing] = useState(false);

  const handleUpvote = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isUpvoted) return;
    setIsUpvoted(true);
    setUpvotes(prev => prev + 1);

    try {
      const updated = await upvoteEditorial(article.id, article.upvotes);
      setUpvotes(updated);
    } catch {}
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const shareUrl = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: article.title,
          text: article.subtitle,
          url: shareUrl
        });
        return;
      } catch {}
    }

    navigator.clipboard?.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!article.amountInNaira) return;
    setIsPurchasing(true);

    initializePaystackCheckout({
      email: userEmail,
      amountInNaira: article.amountInNaira,
      reference: `fash_${article.id}_${Date.now()}`,
      metadata: {
        articleTitle: article.title,
        brand: article.brand,
        itemType: 'Fashion Retail Drop'
      },
      onSuccess: (response) => {
        setIsPurchasing(false);
        if (onPurchaseSuccess) {
          onPurchaseSuccess(article, response.reference);
        }
      },
      onClose: () => {
        setIsPurchasing(false);
      }
    });
  };

  const cleanEmbedUrl = article.youtubeId
    ? `https://www.youtube-nocookie.com/embed/${article.youtubeId}?autoplay=1&enablejsapi=1`
    : null;

  return (
    <article className="group bg-[#111222] border border-white/10 hover:border-[#ff007a]/40 rounded-3xl overflow-hidden transition-all duration-300 hover:shadow-2xl hover:shadow-[#ff007a]/10 flex flex-col justify-between">
      
      {/* Top: Media Cover (High-Resolution Thumbnail or Playable YouTube Stream) */}
      <div className="relative aspect-[16/10] bg-black overflow-hidden">
        {isPlayingInline && cleanEmbedUrl ? (
          <div className="w-full h-full relative">
            <iframe
              src={cleanEmbedUrl}
              title={article.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full border-0"
            />
            <button
              onClick={() => setIsPlayingInline(false)}
              className="absolute top-2.5 right-2.5 p-1.5 rounded-full bg-black/80 hover:bg-black text-white text-xs z-20 backdrop-blur-md"
              title="Close player"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div 
            onClick={() => {
              if (article.youtubeId && onPlayVideo) {
                onPlayVideo(article.youtubeId, article.title);
              }
            }}
            className="w-full h-full cursor-pointer relative"
          >
            <img
              src={article.heroImageUrl}
              alt={article.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />

            {/* Gradient Scrim */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#111222] via-transparent to-black/40 pointer-events-none" />

            {/* Category Pill (Top Left) */}
            <div className="absolute top-3 left-3 flex items-center gap-1.5">
              <span className="px-3 py-1 rounded-full text-[11px] font-black uppercase tracking-wider bg-black/80 backdrop-blur-md text-[#ff007a] border border-[#ff007a]/40 shadow-lg">
                {article.category}
              </span>

              {article.youtubeId && (
                <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-red-600/90 text-white text-[10px] font-bold shadow-md">
                  <Radio className="w-2.5 h-2.5 animate-pulse text-white" />
                  <span>Video Cover</span>
                </span>
              )}
            </div>

            {/* Timestamp (Top Right) */}
            <div className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-white text-[11px] font-mono border border-white/10">
              <Clock className="w-3 h-3 text-slate-400" />
              <span>{article.timeAgo}</span>
            </div>

            {/* Play Button Overlay if video attached */}
            {article.youtubeId && (
              <div className="absolute inset-0 flex items-center justify-center">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsPlayingInline(true);
                  }}
                  className="w-12 h-12 rounded-full bg-black/70 backdrop-blur-md border border-white/30 text-white flex items-center justify-center shadow-xl group-hover:scale-115 group-hover:bg-[#ff007a] transition-all duration-300"
                  title="Play video stream"
                >
                  <Play className="w-5 h-5 fill-white ml-0.5" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Middle: Editorial Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div className="space-y-2">
          
          {/* Brand & Source Line */}
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            <span>{article.brand || 'VibeMeter Editorial'}</span>
            <span className="text-slate-400">{article.sourceName || 'Hypebeast Feed'}</span>
          </div>

          {/* Bold Magazine Headline */}
          <h2 className="text-lg sm:text-xl font-extrabold text-white font-display leading-tight group-hover:text-[#ff007a] transition-colors">
            {article.title}
          </h2>

          {/* Subtitle Excerpt */}
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed line-clamp-3">
            {article.subtitle}
          </p>
        </div>

        {/* Fashion Drop Price Tag & Buy Now Action (Fashion Specific) */}
        {article.priceTag && (
          <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-[#00f2fe]" />
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Retail Drop</span>
                <span className="text-xs sm:text-sm font-extrabold text-[#00f2fe] font-mono">
                  {article.priceTag}
                </span>
              </div>
            </div>

            <button
              onClick={handleBuyNow}
              disabled={isPurchasing}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00f2fe] to-[#4facfe] hover:opacity-95 text-black font-extrabold text-xs shadow-md shadow-[#00f2fe]/20 flex items-center gap-1.5 transition-transform active:scale-95 disabled:opacity-50"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>{isPurchasing ? 'Processing...' : 'Buy Now'}</span>
            </button>
          </div>
        )}

        {/* Tags row */}
        {article.tags && article.tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 pt-1">
            {article.tags.map((t, idx) => (
              <span key={idx} className="text-[10px] font-medium text-slate-400 bg-white/5 px-2 py-0.5 rounded-md">
                #{t}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Bottom: Social & Engagement Toolbar */}
      <div className="px-5 py-3.5 bg-[#141528] border-t border-white/5 flex items-center justify-between">
        
        {/* Like / Fire Button (🔥) */}
        <button
          onClick={handleUpvote}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
            isUpvoted
              ? 'bg-orange-500/25 border border-orange-500/50 text-orange-400 scale-105'
              : 'bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5'
          }`}
          title="Fire Upvote"
        >
          <span className="text-sm">🔥</span>
          <span className="font-mono">{upvotes}</span>
        </button>

        {/* Comment Button (💬) with Live Drawer trigger */}
        <button
          onClick={() => onOpenComments(article)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 transition-all"
          title="Open discussion drawer"
        >
          <span className="text-sm">💬</span>
          <span className="font-mono">{article.commentsCount}</span>
        </button>

        {/* Share Button (🔗) */}
        <button
          onClick={handleShare}
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 transition-all"
          title="Share article link"
        >
          {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
          <span>{copiedLink ? 'Copied' : 'Share'}</span>
        </button>

      </div>

    </article>
  );
};
