import React, { useState, useEffect } from 'react';
import { X, MessageSquare, Send, CheckCircle2, Loader2, Sparkles, User } from 'lucide-react';
import { fetchEditorialComments, postEditorialComment } from '../../services/firebase';

interface EditorialCommentDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  articleId: string;
  articleTitle: string;
  initialCommentsCount: number;
}

export const EditorialCommentDrawer: React.FC<EditorialCommentDrawerProps> = ({
  isOpen,
  onClose,
  articleId,
  articleTitle,
  initialCommentsCount
}) => {
  const [comments, setComments] = useState<any[]>([]);
  const [newText, setNewText] = useState('');
  const [authorName, setAuthorName] = useState('VibeMember');
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!isOpen || !articleId) return;

    const loadComments = async () => {
      setLoading(true);
      try {
        const fallbackList = [
          {
            id: 'c1',
            author: 'Kofi_Kicks',
            text: 'The silhouette on this release is crazy! Definitely copping on the drop date 🔥',
            createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
            timeAgo: '2h ago'
          },
          {
            id: 'c2',
            author: 'Sade_Lagos',
            text: 'Loving how African luxury brands are finally getting international press recognition.',
            createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
            timeAgo: '5h ago'
          }
        ];
        const res = await fetchEditorialComments(articleId, fallbackList);
        setComments(res);
      } catch {
        // Keeps state
      } finally {
        setLoading(false);
      }
    };

    loadComments();
  }, [isOpen, articleId]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;

    setSubmitting(true);
    try {
      const saved = await postEditorialComment(articleId, {
        author: authorName.trim() || 'VIP Collector',
        text: newText.trim(),
        avatar: 'https://i.ytimg.com/vi/4TWRwO8yOQU/hqdefault.jpg'
      });
      setComments(prev => [saved, ...prev]);
      setNewText('');
    } catch {
      // Offline fallback
      setComments(prev => [
        {
          id: `local_${Date.now()}`,
          author: authorName.trim() || 'VIP Collector',
          text: newText.trim(),
          createdAt: new Date().toISOString(),
          timeAgo: 'Just now'
        },
        ...prev
      ]);
      setNewText('');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-[#111222] border-l border-white/10 h-full flex flex-col shadow-2xl relative">
        
        {/* Header */}
        <div className="p-5 border-b border-white/10 bg-[#15162a] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#ff007a]/20 flex items-center justify-center border border-[#ff007a]/40">
              <MessageSquare className="w-4 h-4 text-[#ff007a]" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white font-display">Discussion Feed</h3>
              <p className="text-[11px] text-slate-400">Powered by Firebase Firestore</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-full hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Article Subject Bar */}
        <div className="px-5 py-3 bg-[#18192e] border-b border-white/5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#ff007a] block">
            Discussion on
          </span>
          <h4 className="text-xs font-semibold text-white truncate mt-0.5">
            {articleTitle}
          </h4>
        </div>

        {/* Comments Scrollable Feed */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3.5">
          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center space-y-2">
              <Loader2 className="w-6 h-6 text-[#ff007a] animate-spin" />
              <span className="text-xs text-slate-400">Loading live comments...</span>
            </div>
          ) : comments.length === 0 ? (
            <div className="py-12 text-center space-y-2">
              <Sparkles className="w-8 h-8 text-slate-500 mx-auto" />
              <p className="text-sm font-semibold text-white">No discussions yet</p>
              <p className="text-xs text-slate-400">Be the first collector or curator to leave your take!</p>
            </div>
          ) : (
            comments.map((comm) => (
              <div 
                key={comm.id}
                className="p-3.5 rounded-2xl bg-[#16172d] border border-white/5 space-y-1.5 hover:border-white/10 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-[#ff007a] to-[#8b25ff] flex items-center justify-center text-white text-[10px] font-bold">
                      {comm.author ? comm.author.charAt(0).toUpperCase() : 'U'}
                    </div>
                    <span className="text-xs font-bold text-white">{comm.author}</span>
                  </div>
                  <span className="text-[10px] text-slate-400">{comm.timeAgo || 'Recently'}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pl-8">
                  {comm.text}
                </p>
              </div>
            ))
          )}
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="p-4 border-t border-white/10 bg-[#15162a] space-y-2.5">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={authorName}
              onChange={(e) => setAuthorName(e.target.value)}
              placeholder="Your name or handle"
              className="w-1/3 px-3 py-1.5 rounded-xl bg-[#1b1c34] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
            />
            <span className="text-[11px] text-slate-400">· Leave your editorial thought</span>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              required
              value={newText}
              onChange={(e) => setNewText(e.target.value)}
              placeholder="Add your perspective on this drop..."
              className="flex-1 px-4 py-2.5 rounded-xl bg-[#1b1c34] border border-white/10 text-white text-xs focus:border-[#ff007a] focus:outline-none"
            />
            <button
              type="submit"
              disabled={submitting || !newText.trim()}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#ff007a] to-[#8b25ff] hover:opacity-95 text-white text-xs font-bold flex items-center gap-1.5 transition-transform active:scale-95 disabled:opacity-50"
            >
              {submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              <span>Post</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
